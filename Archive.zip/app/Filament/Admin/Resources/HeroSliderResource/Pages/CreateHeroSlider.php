<?php

namespace App\Filament\Admin\Resources\HeroSliderResource\Pages;

use App\Filament\Admin\Resources\HeroSliderResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateHeroSlider extends CreateRecord
{
    protected static string $resource = HeroSliderResource::class;
}

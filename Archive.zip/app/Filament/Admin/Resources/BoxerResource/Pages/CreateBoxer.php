<?php

namespace App\Filament\Admin\Resources\BoxerResource\Pages;

use App\Filament\Admin\Resources\BoxerResource;
use Filament\Resources\Pages\CreateRecord;

class CreateBoxer extends CreateRecord
{
    protected static string $resource = BoxerResource::class;
} 
<!-- Modal -->
<div class="modal fade popups conslt-popup" id="exampleModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <img src="https://via.placeholder.com/420x591" alt="img">
                <div class="contact-form-one popup">
                    <div class="c-form-2">
                        <h3>Start Consulting</h3>
                        <div class="parallax" style="background-image: url({{ asset('assets/images/pattren.png') }});"></div>
                        <form>
                            <div class="row g-0">
                                <input type="text" class="form-control" id="exampleInputText1" placeholder="Complete Name">
                            </div>
                            <div class="row g-0">
                                <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Email Address">
                            </div>
                            <div class="row g-0">
                                <input type="number" class="form-control" id="exampleInputPassword1" placeholder="Phone No">
                            </div>
                            <div class="row g-0">
                                <select id="inputState-21" class="form-control">
                                    <option selected>Subject</option>
                                    <option>Subject 1</option>
                                    <option>Subject 2</option>
                                    <option>Subject 3</option>
                                </select>
                            </div>
                            <div class="row g-0">
                                <textarea placeholder="Question / Message?"></textarea>
                            </div>
                            <button type="submit" class="theme-btn">Submit Now</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div> 